package com.example.barberapp;

public class Barber extends User{

    String shopName;
    String shopAddress;

    public Barber(String name, String age, String gender, String phoneNumber, String email, String shopName, String shopAddress) {
        super(name, age, gender, phoneNumber, email);
        this.shopName = shopName;
        this.shopAddress = shopAddress;
    }

    public Barber() {
    }

    public String getShopName() {
        return shopName;
    }

    public String getShopAddress() {
        return shopAddress;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public void setShopAddress(String shopAddress) {
        this.shopAddress = shopAddress;
    }
}
