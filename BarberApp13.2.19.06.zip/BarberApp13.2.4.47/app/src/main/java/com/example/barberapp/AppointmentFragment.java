package com.example.barberapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.sql.Time;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AppointmentFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AppointmentFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private CalendarView mCalendarView;
    private ListView mlistView;
    private String curDate;
    private String customerName;
    private String customerPhoneNumber;
    Appointment app;
    Boolean checkDate;
    Boolean checkTime;


    public AppointmentFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AppointmentFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AppointmentFragment newInstance(String param1, String param2) {
        AppointmentFragment fragment = new AppointmentFragment();
        Bundle args = new Bundle();
        ArrayList<Appointment> appointments = new ArrayList<>();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);


        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View appointment_view = inflater.inflate(R.layout.fragment_appointment, container, false);
        SharedPreferences pref = this.getActivity().getApplicationContext().getSharedPreferences("MyPref", 0);// 0 - for private mode
        String barberPhoneNumber = pref.getString("barberPhoneNumber", "");
        SharedPreferences pref1 = this.getActivity().getApplicationContext().getSharedPreferences("MyPref", 0);// 0 - for private mode
        String userEmail = pref1.getString("userEmail", "");


        View lvLayout = appointment_view.findViewById(R.id.AppointmentListViewLayout);
        lvLayout.setVisibility(LinearLayout.INVISIBLE);

        mlistView = appointment_view.findViewById(R.id.listview);
        mCalendarView = appointment_view.findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {


                curDate = (String.valueOf(dayOfMonth) + "-" +String.valueOf(month) + "-" +String.valueOf(year));
                ArrayList<String> list = new ArrayList<>();
                long milli = 32400000l;
                Time t = new Time(milli);
                for(int i=0; i<=47; i++)
                {
                    list.add(t.toString());
                    milli+=900000l;
                    t.setTime(milli);
                }


                ArrayAdapter adapter = new ArrayAdapter(getContext().getApplicationContext(), android.R.layout.simple_list_item_1, list);
                mlistView.setAdapter(adapter);

                lvLayout.setVisibility(LinearLayout.VISIBLE);
            }

        });
        mlistView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {


                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                //Yes button clicked

                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference barberAppRef = database.getReference("Barbers/"+barberPhoneNumber+"/Appointments").child(parent.getItemAtPosition(position).toString()+ " " + curDate);
//                barberAppRef.addListenerForSingleValueEvent(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                        if(dataSnapshot.exists()) {
//                            for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                                    dataSnapshot2.
//                            }
//                        }
//                    }

//                    @Override
//                    public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                    }
//                });
                                DatabaseReference customerRef = FirebaseDatabase.getInstance().getReference("Customer");
                                customerRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if(dataSnapshot.exists())
                                        {
                                            for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){


                                               if (dataSnapshot1.child("email").getValue(String.class).equals(userEmail))
                                                {
                                                    customerPhoneNumber = dataSnapshot1.child("phoneNumber").getValue(String.class);
                                                    customerName = dataSnapshot1.child("name").getValue(String.class);
                                                    DatabaseReference customerAppRef = database.getReference("Customer/"+customerPhoneNumber+"/Appointments").child(parent.getItemAtPosition(position).toString()+ " " + curDate);
                                                    app = new Appointment(parent.getItemAtPosition(position).toString(),curDate,customerPhoneNumber,customerName);


                                                    Toast.makeText(getActivity(), "appiontment taken", Toast.LENGTH_SHORT).show();//זה לא נכון זה בודק את הcustomer ולא את הbarber

                                                    customerAppRef.setValue(app);
                                                    barberAppRef.setValue(app);
                                                    break;
                                                }
                                                else if(dataSnapshot1.getValue() == null)
                                                {
                                                    continue;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            Toast.makeText(getActivity(), "error making appointment", Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked
                                break;
                        }
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Are you sure you want to schedule?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();
            }
        });



                return appointment_view;
    }

}
