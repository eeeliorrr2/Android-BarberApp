package com.example.barberapp;

import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Fragment_Register#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Fragment_Register extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Fragment_Register() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Fragment_Register.
     */
    // TODO: Rename and change types and number of parameters
    public static Fragment_Register newInstance(String param1, String param2) {
        Fragment_Register fragment = new Fragment_Register();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    private FirebaseAuth mAuth;
    CheckBox cbMale,cbFemale,cbOther,cbBarber,cbCustomer;
    LinearLayout barberLayout;
    String gender = null;
    String accountType = "";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    void Register(String name, String age, String gender, String phoneNumber,String email,String accountType,String shopName,String shopAddress,String password){

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getActivity(), "Registered successfully", Toast.LENGTH_SHORT).show();
                            if (accountType.equals("Barber")){
                                Barber barber = new Barber(name,age,gender,phoneNumber,email,shopName,shopAddress);
                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference myRef = database.getReference("Barbers").child(barber.phoneNumber);
                                myRef.setValue(barber);
                            }
                            else {
                                User user = new User(name, age, gender, phoneNumber, email);
                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference myRef = database.getReference("Customer").child(user.phoneNumber);
                                myRef.setValue(user);

                            }
                        }
                        else {
                            Toast.makeText(getActivity(), "register failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View register_view= inflater.inflate(R.layout.fragment__register, container, false);

        mAuth = FirebaseAuth.getInstance();

        cbMale = register_view.findViewById(R.id.checkBoxMale);
        cbFemale = register_view.findViewById(R.id.checkBoxFemale);
        cbOther = register_view.findViewById(R.id.checkBoxOther);

        cbMale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cbFemale.setChecked(false);
                cbOther.setChecked(false);
                gender="Male";
            }
        });

        cbFemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cbMale.setChecked(false);
                cbOther.setChecked(false);
                gender="Female";
            }
        });

        cbOther.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cbFemale.setChecked(false);
                cbMale.setChecked(false);
                gender="Other";
            }
        });

        cbBarber = register_view.findViewById(R.id.checkBoxBarber);
        cbCustomer = register_view.findViewById(R.id.checkBoxCustomer);
        barberLayout = register_view.findViewById(R.id.BarberLayout);
        barberLayout.setVisibility(LinearLayout.INVISIBLE);

        cbBarber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cbCustomer.setChecked(false);
                barberLayout.setVisibility(LinearLayout.VISIBLE);
                accountType = "Barber";
            }
        });

        cbCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cbBarber.setChecked(false);
                barberLayout.setVisibility(LinearLayout.INVISIBLE);
                accountType = "Customer";
            }
        });

        Button button_register = register_view.findViewById(R.id.button_register);

        button_register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){


                String Vname = ((EditText) register_view.findViewById(R.id.editTextPersonNameRegister)).getText().toString();
                String Vage = ((EditText) register_view.findViewById(R.id.editTextAgeRegister)).getText().toString();
                String VphoneNumber = ((EditText) register_view.findViewById(R.id.editTextPhoneRegister)).getText().toString();
                String Vemail = ((EditText) register_view.findViewById(R.id.editTextTextEmailAddressRegister)).getText().toString();
                String Vpassword = ((EditText) register_view.findViewById(R.id.editTextTextPasswordRegister)).getText().toString();
                String VshopName = ((EditText) register_view.findViewById(R.id.editTextBarberShopNameRegister)).getText().toString();
                String VshopAddress = ((EditText) register_view.findViewById(R.id.editTextTextPostalAddressShop)).getText().toString();

                /*switch (accountType){
                    case "Barber":
                        if (VshopName == null || VshopName.isEmpty() || VshopAddress == null || VshopAddress.isEmpty())
                            Toast.makeText(getActivity(), "You have to fill all fields", Toast.LENGTH_SHORT).show();
                        else
                        {
                            Register(Vemail,Vpassword);
                            if (registerFlag) {
                                AddToDB(Vname, Vage, gender, VphoneNumber, Vemail, accountType, VshopName, VshopAddress);
                                Navigation.findNavController(register_view).navigate((R.id.action_fragment_Register_to_fragment_Signin));
                            }
                        }
                        break;

                    case "Customer":
                        if (Vemail == null || Vemail.isEmpty() || Vpassword == null || Vpassword.isEmpty() || Vage == null || Vage.isEmpty() || Vname == null || Vname.isEmpty() || VphoneNumber == null || VphoneNumber.isEmpty())
                            Toast.makeText(getActivity(), "You have to fill all fields", Toast.LENGTH_SHORT).show();
                        else {
                            Register(Vemail, Vpassword);
                            if (registerFlag) {
                                AddToDB(Vname, Vage, gender, VphoneNumber, Vemail, accountType, VshopName, VshopAddress);
                                Navigation.findNavController(register_view).navigate((R.id.action_fragment_Register_to_fragment_Signin));
                            }
                        }
                        break;

                    case "":
                        Toast.makeText(getActivity(), "You have to fill all fields", Toast.LENGTH_SHORT).show();
                        break;

                    default:
                            Register(Vemail,Vpassword);
                            if (registerFlag){
                            AddToDB(Vname, Vage, gender, VphoneNumber, Vemail, accountType, VshopName, VshopAddress);
                            Navigation.findNavController(register_view).navigate((R.id.action_fragment_Register_to_fragment_Signin));
                            }
                }*/


                if ( Vemail.equals("")||
                        Vpassword.equals("")||
                        Vage.equals("")||
                        Vname.equals("")||
                        VphoneNumber.equals(""))
                    Toast.makeText(getActivity(), "You have to fill all fields", Toast.LENGTH_SHORT).show();

                else if(cbBarber.isChecked())
                {
                    if ( VshopName.equals("") ||
                            VshopAddress.equals(""))
                    {
                        Toast.makeText(getActivity(), "You have to fill all fields", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Register(Vname, Vage, gender, VphoneNumber, Vemail, accountType, VshopName, VshopAddress,Vpassword);
                    }
                }
                else {
                    Register(Vname, Vage, gender, VphoneNumber, Vemail, accountType, VshopName, VshopAddress,Vpassword);
                }

            }



        });

        return register_view;
    }


}